import tester.*;
import javalib.worldimages.*;
import javalib.funworld.*;
import java.awt.Color;
import java.util.Random;

interface ILoGamePiece {
   
}

class MtLoBullet implements ILoGamePiece {
  MtLoBullet () {} 
}

class ConsLoBullet implements ILoGamePiece {
  IGamePiece first;
  ILoGamePiece rest;
  
  ConsLoBullet(IGamePiece first, ILoGamePiece rest) {
    this.first = first;
    this.rest = rest; 
  }
  
}

class MtLoShip implements ILoGamePiece {
  MtLoShip () {}
}

class ConsLoShip implements ILoGamePiece {
  IGamePiece first;
  ILoGamePiece rest; 
  
  ConsLoShip(IGamePiece first, ILoGamePiece rest) {
    this.first = first;
    this.rest = rest; 
  }
  
}



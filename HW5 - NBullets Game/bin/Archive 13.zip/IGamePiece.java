import tester.*;
import javalib.worldimages.*;
import javalib.funworld.*;
import java.awt.Color;
import java.util.Random;

interface IGamePiece {
  WorldImage draw(); 
}

abstract class AGamePiece implements IGamePiece {
  int x;
  int y;
  int radius;
  boolean colliding; 
  
  AGamePiece(int x, int y, int radius, boolean colliding) {
    this.x = x;
    this.y = y;
    this.radius = radius; 
    this.colliding = colliding; 
  }
  
}

class Bullet extends AGamePiece {
  int explosions; 
  
  Bullet(int x, int y, int radius, boolean colliding, int explosions) {
    super(x, y, radius, colliding);
    this.explosions = explosions; 
  }
  
  public WorldImage draw() {
    return new CircleImage(10, OutlineMode.SOLID, Color.cyan);
  }
}


class Ship extends AGamePiece {
  
  Ship(int x, int y, int radius, boolean colliding) {
    super(x, y, radius, colliding);
  }
  
  public WorldImage draw() {
    return new CircleImage(2, OutlineMode.SOLID, Color.pink);
  }
  
}

class GamePieceExamples{
  
}
import tester.*;
import javalib.worldimages.*;
import javalib.funworld.*;
import java.awt.Color;
import java.util.Random;

interface ILoGamePiece {
   boolean isEmpty();
   ILoGamePiece fixRange(); 
   ILoGamePiece createShipsLeft();
   ILoGamePiece createShipsRight(); 
   WorldScene drawList(WorldScene scene);
   ILoGamePiece changeXList(); 
}

class MtLoBullet implements ILoGamePiece {
  MtLoBullet () {} 
  
  public boolean isEmpty() {
    return true; 
  }
  
  public ILoGamePiece fixRange() {
    return this; 
  }
  
  public ILoGamePiece createShipsLeft() {
    throw new IllegalStateException("Method cannot invoked");
  }
  
  public ILoGamePiece createShipsRight() {
    throw new IllegalStateException("Method cannot invoked"); 
  }
  
  public WorldScene drawList(WorldScene scene) {
    return scene; 
  }
  
  public ILoGamePiece changeXList() {
    return this; 
  }
  
  
}

class ConsLoBullet implements ILoGamePiece {
  IGamePiece first;
  ILoGamePiece rest;
  
  ConsLoBullet(IGamePiece first, ILoGamePiece rest) {
    this.first = first;
    this.rest = rest; 
  } 
  
  public boolean isEmpty() {
    return false; 
  }
  
  public ILoGamePiece fixRange() {
    return this; 
  }

  public ILoGamePiece createShipsLeft() {
    throw new IllegalStateException("Method cannot invoked");
  }
  
  public ILoGamePiece createShipsRight() {
    throw new IllegalStateException("Method cannot invoked"); 
  }
  
  public WorldScene drawList(WorldScene scene) {
    return scene; 
  }
  
  public ILoGamePiece changeXList() {
    return this; 
  }
  
}

class MtLoShip implements ILoGamePiece {
  MtLoShip () {}
  
  public boolean isEmpty() {
    return true; 
  }
  
  public ILoGamePiece fixRange() {
    return this; 
  }
  
  public ILoGamePiece createShipsLeft() {
    Random r = new Random();
    int randShip = r.nextInt(3) + 1; 
    int randY1 = r.nextInt((257 - 43) + 1) + 43;
    int randY2 = r.nextInt((257 - 43) + 1) + 43;
    int randY3 = r.nextInt((257 - 43) + 1) + 43;
    
    if (randShip == 1) {
      return new ConsLoShip(new ShipLeft(10, randY1, 10, false), this); 
    } else if (randShip == 2) {
      return new ConsLoShip(new ShipLeft(10, randY1, 10, false),
          new ConsLoShip(new ShipLeft(10, randY2, 10, false), this));
    } else {
      return new ConsLoShip(new ShipLeft(10, randY1, 10, false),
          new ConsLoShip(new ShipLeft(10, randY2, 10, false),
              new ConsLoShip(new ShipLeft(10, randY3, 10, false), this)));
    }   
  }
  
  public ILoGamePiece createShipsRight() {
    Random r = new Random();
    int randShip = r.nextInt(3) + 1; 
    int randY1 = r.nextInt((257 - 43) + 1) + 43;
    int randY2 = r.nextInt((257 - 43) + 1) + 43;
    int randY3 = r.nextInt((257 - 43) + 1) + 43;
    
    if (randShip == 1) {
      return new ConsLoShip(new ShipRight(490, randY1, 10, false), this); 
    } else if (randShip == 2) {
      return new ConsLoShip(new ShipRight(490, randY1, 10, false),
          new ConsLoShip(new ShipRight(490, randY2, 10, false), this));
    } else {
      return new ConsLoShip(new ShipRight(490, randY1, 10, false),
          new ConsLoShip(new ShipRight(490, randY2, 10, false),
              new ConsLoShip(new ShipRight(490, randY3, 10, false), this)));
    }
    
  }
  
  public WorldScene drawList(WorldScene scene) {
    return scene; 
  }
  
  public ILoGamePiece changeXList() {
    return this; 
  }
  
}

class ConsLoShip implements ILoGamePiece {
  IGamePiece first;
  ILoGamePiece rest; 
  
  ConsLoShip(IGamePiece first, ILoGamePiece rest) {
    this.first = first;
    this.rest = rest; 
  }
  
  public boolean isEmpty() {
    return false; 
  }
  
  public ILoGamePiece fixRange() {
    if (this.first.inRange()) {
      return new ConsLoShip(this.first, this.rest.fixRange());
    }
    else {
      return this.rest.fixRange();
    }
  }

  public ILoGamePiece createShipsLeft() {
    Random r = new Random();
    int randShip = r.nextInt(3) + 1; 
    int randY1 = r.nextInt((257 - 43) + 1) + 43;
    int randY2 = r.nextInt((257 - 43) + 1) + 43;
    int randY3 = r.nextInt((257 - 43) + 1) + 43;
    
    if (randShip == 1) {
      return new ConsLoShip(new ShipLeft(-10, randY1, 10, false), this); 
    } else if (randShip == 2) {
      return new ConsLoShip(new ShipLeft(-10, randY1, 10, false),
          new ConsLoShip(new ShipLeft(-10, randY2, 10, false), this));
    } else {
      return new ConsLoShip(new ShipLeft(-10, randY1, 10, false),
          new ConsLoShip(new ShipLeft(-10, randY2, 10, false),
              new ConsLoShip(new ShipLeft(-10, randY3, 10, false), this)));
    }   
  }
  
  public ILoGamePiece createShipsRight() { 
    Random r = new Random();
    int randShip = r.nextInt(3) + 1; 
    int randY1 = r.nextInt((257 - 43) + 1) + 43;
    int randY2 = r.nextInt((257 - 43) + 1) + 43;
    int randY3 = r.nextInt((257 - 43) + 1) + 43;
    
    if (randShip == 1) {
      return new ConsLoShip(new ShipRight(510, randY1, 10, false), this); 
    } else if (randShip == 2) {
      return new ConsLoShip(new ShipRight(510, randY1, 10, false),
          new ConsLoShip(new ShipRight(510, randY2, 10, false), this));
    } else {
      return new ConsLoShip(new ShipRight(510, randY1, 10, false),
          new ConsLoShip(new ShipRight(510, randY2, 10, false),
              new ConsLoShip(new ShipRight(510, randY3, 10, false), this)));
    }
    
  }
  
  public WorldScene drawList(WorldScene scene) {
    scene = this.first.toScene(scene);
    return this.rest.drawList(scene); 
    
  }
  
  public ILoGamePiece changeXList() {
      return new ConsLoShip(this.first.changeXShip(), this.rest.changeXList()); 
  }

}



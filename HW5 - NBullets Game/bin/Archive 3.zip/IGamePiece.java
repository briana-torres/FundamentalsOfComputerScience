import tester.*;
import javalib.worldimages.*;
import javalib.funworld.*;
import java.awt.Color;
import java.util.Random;

interface IGamePiece {
  WorldImage draw();  
  boolean inRange();  
  WorldScene toScene(WorldScene scene);   
  IGamePiece changeXShip();

}

class Bullet implements IGamePiece {
  int x;
  int y;
  int radius;
  int explosions; 
  
  Bullet(int x, int y, int radius, boolean colliding, int explosions) {
    this.x = x;
    this.y = y;
    this.radius = radius; 
    this.explosions = explosions; 
  }
  
  public WorldImage draw() {
    return new CircleImage(this.radius, OutlineMode.SOLID, Color.pink);
  }
  
  public boolean inRange(){
    if (this.x >= 0 && this.x <= 500 && this.y >= 0 && this.y <= 300) {
      return true; 
    } else {
      return false; 
    }
  }
 
  public WorldScene toScene(WorldScene scene) {
    return scene.placeImageXY(this.draw(), this.x, this.y); 
  }
  
  public IGamePiece changeXShip() {
    return this; 
  }
  
}


class ShipLeft implements IGamePiece {
  int x;
  int y;
  int radius;
  boolean colliding; 
  
  ShipLeft(int x, int y, int radius, boolean colliding) {
    this.x = x;
    this.y = y;
    this.radius = radius; 
    this.colliding = colliding;
  }
  
  public WorldImage draw() {
    return new CircleImage(10, OutlineMode.SOLID, Color.cyan);
  }
  
  public boolean inRange() {
    if (this.x >= -10 && this.x <= 510) {
      return true;
    }
    else {
      return false;
    }
  }
  
  public WorldScene toScene(WorldScene scene) {
    return scene.placeImageXY(this.draw(), this.x, this.y); 
  }
  
  public IGamePiece changeXShip() {
    this.x = this.x + 10; 
    return this;
  }
  
}

class ShipRight implements IGamePiece {
  int x;
  int y;
  int radius;
  boolean colliding; 
  
  ShipRight(int x, int y, int radius, boolean colliding) {
    this.x = x;
    this.y = y;
    this.radius = radius; 
    this.colliding = colliding; 
  }
  
  public WorldImage draw() {
    return new CircleImage(10, OutlineMode.SOLID, Color.cyan);
  }
  
  public boolean inRange() {
    if (this.x >= -10 && this.x <= 510) {
      return true;
    }
    else {
      return false;
    }
  }
  
  public WorldScene toScene(WorldScene scene) {
    return scene.placeImageXY(this.draw(), this.x, this.y); 
  }
  
  public IGamePiece changeXShip() {
    this.x = this.x - 10;
    return this;
  }
  
}

class GamePieceExamples{
  
}
import tester.*;
import javalib.worldimages.*;
import javalib.funworld.*;
import java.awt.Color;
import java.util.Random;

class Game extends World {
  int WIDTH = 500;
  int HEIGHT = 300;
  int bullets;
  int destroyedShips;
  int currentTick;
  
  ILoGamePiece bulletList;
  ILoGamePiece shipList; 
  
  boolean moveBullets;
  boolean moveShips; 
  boolean spawnShips; 
  boolean deleteShips; 
  boolean left; 
  
  Random rand; 
  
  /*
  Game(int bullets) {
    this(
  }
  needs to take in ship list 
  */
  
  Game(int bullets) {
    this(bullets, 0, 0, new MtLoShip(), true, true, true, true);
  }
  
  Game(int bullets, int destroyedShips, int currentTick, ILoGamePiece shipList, boolean moveShips,
      boolean spawnShips, boolean deleteShips, boolean left) {
    this.bullets = bullets;
    this.destroyedShips = destroyedShips;
    this.currentTick = currentTick;
    this.shipList = shipList;
    this.moveShips = moveShips;
    this.spawnShips = spawnShips;
    this.deleteShips = deleteShips;
    this.left = left; 
  }

  @Override
  public WorldScene makeScene() {

    WorldScene scene = new WorldScene(WIDTH, HEIGHT);
    
    if (this.deleteShips) {
      scene = this.deleteShipsHelper(scene);
    }
    
    if (this.spawnShips) {
      scene = this.spawnShipsHelper(scene);
    }
    
    if (this.moveShips) {
      scene = this.moveShipsHelper(scene);
    }
    
    scene = this.addInfoToScene(scene);
    
    return scene; 
    //return scene.placeImageXY(new CircleImage(10, OutlineMode.SOLID, Color.green), 480 - 10 * currentTick, 200);
  }
  
  /*
  @Override
  public Game onKeyEvent(String key) {
    // did we press the space update the final tick of the game by 10.
    if (key.equals(" ")) {
      return new Game(this.WIDTH, this.HEIGHT, this.currentTick, this.finalTick + 10, true,
          false);
    }
    else {
      return this;
    }
  }
  */
  
  public Game onTick() {
    return this.deleteShips().spawnShips().moveShips().incrementGameTick();
  }
  
  public Game deleteShips() {
    return new Game(this.bullets, this.destroyedShips, this.currentTick, this.shipList,
        this.moveShips, this.spawnShips, true, this.left);
  }

  public Game spawnShips() {
    return new Game(this.bullets, this.destroyedShips, this.currentTick, this.shipList,
        this.moveShips, true, this.deleteShips, this.left);
  }

  public Game moveShips() {
    return new Game(this.bullets, this.destroyedShips, this.currentTick, this.shipList, true,
        this.spawnShips, this.deleteShips, this.left);
  }

  public Game incrementGameTick() {
    return new Game(this.bullets, this.destroyedShips, this.currentTick + 1, this.shipList,
        this.moveShips, this.spawnShips, this.deleteShips, this.left);
  }

  WorldScene addInfoToScene(WorldScene scene) {
    return scene.placeImageXY(new TextImage("Bullets: " + Integer.toString(this.bullets)
        + "  Destroyed Ships: " + Integer.toString(this.destroyedShips), Color.black), 100, 20);
  }
  
  WorldScene deleteShipsHelper(WorldScene scene) {
    if (this.shipList.isEmpty()) {
      return scene; 
    } else {
      this.shipList = this.shipList.fixRange(); 
      return this.shipList.drawList(scene); 
    }
  }

  WorldScene spawnShipsHelper(WorldScene scene) {
    
    if (this.currentTick % 4 == 0) {
      this.left = !this.left; 
      if (this.left) {
        this.shipList = this.shipList.createShipsLeft(); 
        return this.shipList.drawList(scene);  
      } else { 
        this.shipList = this.shipList.createShipsRight(); 
        return this.shipList.drawList(scene);
      }
    } else { 
      return scene;  
    } 
    
  }
  
  WorldScene moveShipsHelper(WorldScene scene) {
  
    this.shipList = this.shipList.changeXList(); 
    return this.shipList.drawList(scene); 
    
  }

  @Override
  public WorldEnd worldEnds() {
    if (this.bullets < 0) {
      return new WorldEnd(true, this.makeEndScene());
    }
    else {
      return new WorldEnd(false, this.makeEndScene());
    }
  }

  public WorldScene makeEndScene() {
    WorldScene endScene = new WorldScene(this.WIDTH, this.HEIGHT);
    return endScene.placeImageXY(new TextImage("Game Over", Color.red), 250, 250);

  }
}

class ExamplesMyWorld {
  boolean testBigBang(Tester t) {
    Game game = new Game(10);
    return game.bigBang(500, 300, 1);
  }
}